/*
 * Copyright (C) 2014 Glyptodon LLC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package org.glyptodon.guacamole.net.basic.rest.guest;

import com.google.inject.Inject;
import org.glyptodon.guacamole.GuacamoleException;
import org.glyptodon.guacamole.net.basic.GuacamoleSession;
import org.glyptodon.guacamole.net.basic.rest.ObjectRetrievalService;
import org.glyptodon.guacamole.net.basic.rest.auth.AuthenticationService;
import org.glyptodon.guacamole.net.basic.rest.connection.APIConnection;
import org.glyptodon.guacamole.net.basic.rest.db.ConnectionFactory;
import org.glyptodon.guacamole.net.basic.rest.db.DbUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;


/**
 * A REST Service for handling connection CRUD operations.
 *
 * @author James Muehlner
 */



@Path("/data/{dataSource}/guests")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class GuestRESTService {

    private Connection connection;
    private Statement statement;
    private PreparedStatement preparedStatement;

    /**
     * Logger for this class.
     */
    private static final Logger logger = LoggerFactory.getLogger(GuestRESTService.class);

    /**
     * A service for authenticating users from auth tokens.
     */
    @Inject
    private AuthenticationService authenticationService;

    /**
     * Service for convenient retrieval of objects.
     */
    @Inject
    private ObjectRetrievalService retrievalService;

    /**
     * Retrieves the parameters associated with a single connection.
     *
     * @param authToken
     *     The authentication token that is used to authenticate the user
     *     performing the operation.
     *
     * @param authProviderIdentifier
     *     The unique identifier of the AuthenticationProvider associated with
     *     the UserContext containing the connection whose parameters are to be
     *     retrieved.
     *
     * @param jobID
     *     The identifier of the connection.
     *
     * @return
     *     A map of parameter name/value pairs.
     *
     * @throws GuacamoleException
     *     If an error occurs while retrieving the connection parameters.
     */
    @GET
    @Path("/{jobID}/retrieve")
    public  Map<Integer, Map> retrieveConnection(@QueryParam("token") String authToken,
                                                  @PathParam("dataSource") String authProviderIdentifier,
                                                  @PathParam("jobID") String jobID)
            throws Exception {


        GuacamoleSession session = authenticationService.getGuacamoleSession(authToken);
        //UserContext userContext = retrievalService.retrieveUserContext(session, authProviderIdentifier);
        //User self = userContext.self();
        String query = "SELECT Guest_Id, GuestUser, FullName, FirstName, LastName, Email, Password, Country, Address, if(CreatedAt = '0000-00-00', ' ', CreatedAt) as CreatedAt, if(UpdatedAt = '0000-00-00', ' ', UpdatedAt) as UpdatedAt FROM Guests";
        ResultSet rs = null;

        Map<Integer, Map> JSONvalue = new HashMap<Integer, Map>();
        Integer i = 0;
        try {
            connection = ConnectionFactory.getConnection();
            statement = connection.createStatement();
            rs = statement.executeQuery(query);
            while (rs.next()) {
                i= i+1;
                Map<String, String> parameters = new HashMap<String, String>();
                parameters.put("Guest_Id",rs.getString("Guest_Id"));
                parameters.put("GuestUser",rs.getString("GuestUser"));
                parameters.put("FullName",rs.getString("FullName"));
                parameters.put("FirstName",rs.getString("FirstName"));
                parameters.put("LastName",rs.getString("LastName"));
                parameters.put("Email",rs.getString("Email"));
                parameters.put("Password",rs.getString("Password"));
                parameters.put("Country",rs.getString("Country"));
                parameters.put("Address",rs.getString("Address"));
                parameters.put("CreatedAt",rs.getString("CreatedAt"));
                parameters.put("UpdatedAt",rs.getString("UpdatedAt"));

                JSONvalue.put(i,parameters);

            }

        } finally {
            DbUtil.close(rs);
            DbUtil.close(statement);
            DbUtil.close(connection);
        }
        //JSONvalue = JSONvalue.substring(0,JSONvalue.toString().length()-1)+"]";
        return JSONvalue;

    }

    /**
     * Deletes an individual connection.
     *
     * @param authToken
     *     The authentication token that is used to authenticate the user
     *     performing the operation.
     *
     * @param authProviderIdentifier
     *     The unique identifier of the AuthenticationProvider associated with
     *     the UserContext containing the connection to be deleted.
     *
     * @param jobID
     *     The identifier of the connection to delete.
     *
     * @throws GuacamoleException
     *     If an error occurs while deleting the connection.
     */

    @DELETE
    @Path("/{jobID}")
    public void deleteJob(@QueryParam("token") String authToken,
                          @PathParam("dataSource") String authProviderIdentifier,
                          @PathParam("jobID") String jobID)
            throws Exception {

        PreparedStatement preparedStatement = null;

        String deleteSQL = "DELETE from Guests WHERE Guest_Id = ? ";
        try {
            connection = ConnectionFactory.getConnection();
            preparedStatement = connection.prepareStatement(deleteSQL);
            preparedStatement.setString(1, jobID);

            // execute delete SQL stetement
            preparedStatement.executeUpdate();

            connection.commit();

            System.out.println("Record is deleted!");

        } catch (Exception e) {

            System.out.println(e.getMessage());

        } finally {

            if (preparedStatement != null) {
                preparedStatement.close();
            }

            if (connection != null) {
                connection.close();
            }

        }


    }

    @PUT
    @Path("/{jobID}")
    public void updateJob(@QueryParam("token") String authToken,
                          @PathParam("dataSource") String authProviderIdentifier,
                          @PathParam("jobID") String jobID,
                          APIConnection connection2) throws Exception {

        GuacamoleSession session = authenticationService.getGuacamoleSession(authToken);
        //UserContext userContext = retrievalService.retrieveUserContext(session, authProviderIdentifier);

        // APIConnection is not this module's input data.
        // you can see only this code.
        PreparedStatement ps = null;
        try {
            connection = ConnectionFactory.getConnection();

            // create our java preparedstatement using a sql update query
            ps = connection.prepareStatement("UPDATE Guests SET Title = ?, Content = ? WHERE Job_Id = ?");

            // set the preparedstatement parameters
            ps.setString(1,"ssddd");
            ps.setString(2,"sdsfdfdgfgfgf");
            ps.setString(3,jobID);

            // call executeUpdate to execute our sql update statement
            ps.executeUpdate();
        }catch (Exception e) {

            System.out.println(e.getMessage());

        } finally {

            if (preparedStatement != null) {
                preparedStatement.close();
            }

            if (connection != null) {
                connection.close();
            }

        }

        //Dynamic SQL
        //input data (JSON)= "["Title":"sdsffdgfdd", "Content":"dfsdfdfdgfghggjgghg"....."
        //exapmple

        //String data = "{'Title':'sdsffdgfdd','Content':'dfsdfdfdgfghggjgghg'}";

        //JSONParser parser = new JSONParser();



    }

    /**
     * Retrieves an individual connection.
     *
     * @param authToken
     *     The authentication token that is used to authenticate the user
     *     performing the operation.
     *
     * @param authProviderIdentifier
     *     The unique identifier of the AuthenticationProvider associated with
     *     the UserContext containing the connection to be retrieved.
     *
     * @param jobID
     *     The identifier of the connection to retrieve.
     *
     * @return
     *     The connection having the given identifier.
     *
     * @throws GuacamoleException
     *     If an error occurs while retrieving the connection.
     */
    /*
    @GET
    @Path("/{jobID}")
    public APIJob getJob(@QueryParam("token") String authToken,
                                       @PathParam("dataSource") String authProviderIdentifier,
                                       @PathParam("jobID") String jobID)
            throws GuacamoleException {

        GuacamoleSession session = authenticationService.getGuacamoleSession(authToken);

        // Retrieve the requested connection
        return new APIJob(retrievalService.retrieveJob(session, authProviderIdentifier, jobID));

    }*/




    /**
     * Retrieves the usage history of a single connection.
     *
     * @param authToken
     *     The authentication token that is used to authenticate the user
     *     performing the operation.
     *
     * @param authProviderIdentifier
     *     The unique identifier of the AuthenticationProvider associated with
     *     the UserContext containing the connection whose history is to be
     *     retrieved.
     *
     * @param jobID
     *     The identifier of the connection.
     *
     * @return
     *     A list of connection records, describing the start and end times of
     *     various usages of this connection.
     *
     * @throws GuacamoleException
     *     If an error occurs while retrieving the connection history.
     */
    /*
    @GET
    @Path("/{jobID}/history")
    public List<APIConnectionRecord> getJobHistory(@QueryParam("token") String authToken,
                                                          @PathParam("dataSource") String authProviderIdentifier,
                                                          @PathParam("jobID") String jobID)
            throws GuacamoleException {

        GuacamoleSession session = authenticationService.getGuacamoleSession(authToken);

        // Retrieve the requested connection

        // Retrieve the requested connection's history


        // Return the converted history
        return apiRecords;

    }
    */

    /**
     * Deletes an individual connection.
     *
     * @param authToken
     *     The authentication token that is used to authenticate the user
     *     performing the operation.
     *
     * @param authProviderIdentifier
     *     The unique identifier of the AuthenticationProvider associated with
     *     the UserContext containing the connection to be deleted.
     *
     * @param jobID
     *     The identifier of the connection to delete.
     *
     * @throws GuacamoleException
     *     If an error occurs while deleting the connection.
     */
    /*
    @DELETE
    @Path("/{jobID}")
    public void deleteJob(@QueryParam("token") String authToken,
                                 @PathParam("dataSource") String authProviderIdentifier,
                                 @PathParam("jobID") String jobID)
            throws GuacamoleException {

        GuacamoleSession session = authenticationService.getGuacamoleSession(authToken);
        UserContext userContext = retrievalService.retrieveUserContext(session, authProviderIdentifier);

        // Get the connection directory

        // Delete the specified connection

    }
*/
    /**
     * Creates a new connection and returns the new connection, with identifier
     * field populated.
     *
     * @param authToken
     *     The authentication token that is used to authenticate the user
     *     performing the operation.
     *
     * @param authProviderIdentifier
     *     The unique identifier of the AuthenticationProvider associated with
     *     the UserContext in which the connection is to be created.
     *
     * @param job
     *     The connection to create.
     *
     * @return
     *     The new connection.
     *
     * @throws GuacamoleException
     *     If an error occurs while creating the connection.
     */
    /*
    @POST
    public GuacamoleSession createJob(@QueryParam("token") String authToken,
                                          @PathParam("dataSource") String authProviderIdentifier,
                                          APIJob job) throws GuacamoleException {

        GuacamoleSession session = authenticationService.getGuacamoleSession(authToken);
       /* UserContext userContext = retrievalService.retrieveUserContext(session, authProviderIdentifier);

        // Validate that connection data was provided

        // Add the new connection

        // Return the new connection
        return session;



    }*/

    /**
     * Updates an existing connection. If the parent identifier of the
     * connection is changed, the connection will also be moved to the new
     * parent group.
     *
     * @param authToken
     *     The authentication token that is used to authenticate the user
     *     performing the operation.
     *
     * @param authProviderIdentifier
     *     The unique identifier of the AuthenticationProvider associated with
     *     the UserContext containing the connection to be updated.
     *
     * @param jobID
     *     The identifier of the connection to update.
     *
     * @param job
     *     The connection data to update the specified connection with.
     *
     * @throws GuacamoleException
     *     If an error occurs while updating the connection.
     */
    /*
    @PUT
    @Path("/{jobID}")
    public void updateJob(@QueryParam("token") String authToken,
                                 @PathParam("dataSource") String authProviderIdentifier,
                                 @PathParam("jobID") String jobID,
                                 APIJob job) throws GuacamoleException {

        GuacamoleSession session = authenticationService.getGuacamoleSession(authToken);
        UserContext userContext = retrievalService.retrieveUserContext(session, authProviderIdentifier);

        // Validate that connection data was provided

        // Get the connection directory

        // Retrieve connection to update

        // Build updated configuration

        // Update the connection

*/
    //}

}
