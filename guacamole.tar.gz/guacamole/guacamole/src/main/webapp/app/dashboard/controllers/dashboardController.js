/*
 * Copyright (C) 2016 David
 *
 /
 
/**
 * The controller for the interview page.
 */
angular.module('dashboard').controller('dashboardController', ['$scope', '$injector', 
        function homeController($scope, $injector) {

    // Get required types
    var ConnectionGroup  = $injector.get('ConnectionGroup');
    var $rootScope  	 = $injector.get('$rootScope');
    
    // Get required services
    var authenticationService  = $injector.get('authenticationService');
    var $location              = $injector.get('$location');  

    /*
    *	sign out
    */
    $scope.signOut = function signOut() {

    }

    /*
    *  job items
    */
    $scope.jobs = [
    	{id: 0, title: 'Firewall Administrator 1'},
    	{id: 1, title: 'Firewall Administrator 2'},
    	{id: 2, title: 'MalWare Analyst'},
    	{id: 3, title: 'Digital Forensiic Examiner'},
    	{id: 4, title: 'Firewall Administrator 3'}
    ];

    /*
    *  Candidates
    */

    $scope.candidates = [
    	{id: 0, name: 'John Smith', email: 'a@a.a'},
    	{id: 1, name: 'Jerry Springer', email: 'a@a.a'},
    	{id: 2, name: 'Sam Jones', email: 'a@a.a'},
    	{id: 3, name: 'Stev Hamalton', email: 'a@a.a'},
    	{id: 4, name: 'Jimy John', email: 'a@a.a'},
    	{id: 5, name: 'Henry Blank', email: 'a@a.a'}
    ];

    /*
    *   accounts
    */
    $scope.accounts = [
    	{id: 0, theme: 'Billing'},
    	{id: 1, theme: 'Information'},
    	{id: 2, theme: 'Invoices'}
    ];
    
    $scope.onJobClick = function onJobClick(job) {
    	$location.url('/job');
    }

	$scope.onCandidateClick = function onCandidateClick(candidate) {
		console.log(candidate);
    }

    $scope.onAccountClick = function onAccountClick(account) {
    	console.log(account);
    }    

    /**
     * Logs out the current user, redirecting them to back to the root
     * after logout completes.
     */
    $scope.logout = function logout() {
        authenticationService.logout()['finally'](function logoutComplete() {
            $location.url('/');
            $rootScope.$broadcast('guacLogout');
        });
    };
        
}]);
