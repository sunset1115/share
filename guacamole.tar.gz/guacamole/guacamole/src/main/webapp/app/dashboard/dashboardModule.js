
angular.module('dashboard', [
    'auth',
    'element',
    'history',
    'navigation',
    'ngMaterial'
]);
