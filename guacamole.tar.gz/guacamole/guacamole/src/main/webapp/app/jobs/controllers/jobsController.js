/*
 * Copyright (C) 2016 David
 *
 /
 
/**
 * The controller for the interview page.
 */
angular.module('jobs').controller('jobsController', ['$scope', '$injector', function homeController($scope, $injector) {

    // Get required types
    var ConnectionGroup  = $injector.get('ConnectionGroup');
    var $rootScope  	 = $injector.get('$rootScope');
    var JobService       = $injector.get('jobService');
    
    // Get required services
    var authenticationService  = $injector.get('authenticationService');
    var $location              = $injector.get('$location');
    // var $routeParams    = $injector.get('$routeParams');

    $scope.username = authenticationService.getCurrentUsername();
    // $scope.selectedDataSource = $routeParams.dataSource;

    $scope.postJob = function PostJob() {
        $location.path('/jobs/' + 0 );
    }
    
    $scope.find = function getAllJobs() {
        JobService.retrieveJobs('mysql', null)
            .success(function(data) {
                console.log(data);
            });
        //console.log(JobService);
    }

}]);
