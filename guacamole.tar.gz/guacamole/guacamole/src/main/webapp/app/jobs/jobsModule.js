
angular.module('jobs', [
    'auth',
    'element',
    'history',
    'navigation',
    'ngMaterial'
]);
