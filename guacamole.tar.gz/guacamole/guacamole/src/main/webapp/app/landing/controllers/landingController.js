/* @Copyright 2016-06-13 David
*   landing page controller
*/

angular.module('landing').controller('landingController', ['$scope', '$injector', 
        function homeController($scope, $injector) {

    // Get required types
    var $rootScope      = $injector.get('$rootScope');

    // Get required services
    var $location       = $injector.get('$location');    

    $scope.headerBtn = [
            {
                caption: 'Post a Job',
                link: 'jobs'
            },
            {
                caption: 'Interview',
                link: 'dashboard'
            },
            {
                caption: 'Evaluate',
                link: 'evaluate'
            },
            {
                caption: 'Join',
                link: 'signup'
            }
        ];    

    $scope.goByHeaderBtn = function goByHeaderBtn(link) {        
        
        $location.url('/' + link);        
    }

    /**
     * Logs out the current user, redirecting them to back to the root
     * after logout completes.
     */
    $scope.logout = function logout() {
        authenticationService.logout()['finally'](function logoutComplete() {
            
            if ($location.path() !== '/')
                $location.url('/');
            else{
                $scope.showLoginBtnFlag = true;
                $route.reload();
            }

        });
    };

    $scope.showLoginPage = function () {
        $rootScope.$broadcast("showLoginPage");
    } 

    $scope.isLoaded = function isLoaded() {
        return true;
    };  

}]);
