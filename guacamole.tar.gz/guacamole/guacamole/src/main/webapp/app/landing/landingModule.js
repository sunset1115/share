/*
 * Copyright (C) 2016-06-13 David
 * This is inspector of lannding module.
 */

angular.module('landing', ['ngMaterial']);