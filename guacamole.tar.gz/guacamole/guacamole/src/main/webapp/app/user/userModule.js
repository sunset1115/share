/*
 * Copyright (C) 2016-06-13 David
 * 
 */

/**
 * The module for the login module of user.
 */
angular.module('user', [
    'element',
    'form',
    'navigation'
]);
